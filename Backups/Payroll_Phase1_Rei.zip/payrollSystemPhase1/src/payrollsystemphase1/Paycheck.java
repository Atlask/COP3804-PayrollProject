/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payrollsystemphase1;

/**
 *
 * @author Rei
 */
    public class Paycheck{
    
        private int employeeID;
        private String periodBeginDate;
        private String periodEndDate;
        private double grossAmount;
        private double taxAmount;
        private double bonusAmount;
        private double netAmount;

}
    

