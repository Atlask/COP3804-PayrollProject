package payrollsystemphase1;

import java.util.ArrayList;


    public class Department{
        
        private int departmentID;
        private String departmentName;
        private String departmentManager;
        private ArrayList listOfEmployees;
        
    }

