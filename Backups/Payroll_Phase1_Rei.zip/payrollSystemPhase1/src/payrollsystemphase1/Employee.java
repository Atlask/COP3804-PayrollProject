/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payrollsystemphase1;

import java.util.ArrayList;

public class Employee{
       private int employeeID;
       private String firstName;
       private String lastName;
        //List<String> strList = new ArrayList<String>();
        private ArrayList listOfPaycheck;

        public Employee(int employeeID, String firstName, String lastName) {
            this.listOfPaycheck = new ArrayList();
            this.employeeID = employeeID;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public int getEmployeeID() {
            return employeeID;
        }

        public void setEmployeeID(int employeeID) {
            this.employeeID = employeeID;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public ArrayList getPaycheck() {
            return listOfPaycheck;
        }

        public void setPaycheck(ArrayList Paycheck) {
            this.listOfPaycheck = Paycheck;
        }
        
    }
