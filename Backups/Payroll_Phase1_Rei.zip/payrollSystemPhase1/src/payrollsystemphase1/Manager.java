package payrollsystemphase1;

  public class Manager extends SalariedEmployee{
        
        private double bonus;
        
        public Manager(int employeeID, String firstName, String lastName) {
            super(employeeID, firstName, lastName);
        }
        
    }