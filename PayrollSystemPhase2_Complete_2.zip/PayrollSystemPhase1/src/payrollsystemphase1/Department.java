/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payrollsystemphase1;

import java.util.ArrayList;

/**
 *
 * 
 */
public class Department {

    private int departmentID;
    private String departmentName;

    private Manager departmentManager;
    private ArrayList<Employee> listOfEmployees = new ArrayList<Employee>();
    //departmentManager Manager = new departmentManager();
    //List<String> strList = new ArrayList<String>();
    //ArrayList Paycheck = new ArrayList();

    public Department(int departmentID, String departmentName, Manager departmentManager, ArrayList<Employee> listOfEmployees) {
        this.departmentID = departmentID;
        this.departmentName = departmentName;

        //ArrayList<Employee> listOfEmployeesCopy = new ArrayList<Employee>();
       /* if (departmentManager instanceof Manager) {*/
            this.departmentManager = new Manager(departmentManager);
        

        if (listOfEmployees != null) {

            for (Employee EmployeeElements : listOfEmployees) {
                if (EmployeeElements instanceof Manager) {
                    Manager m = (Manager) ((SalariedEmployee) EmployeeElements);
                    this.listOfEmployees.add(new Manager(m));

                } else if (EmployeeElements instanceof SalariedEmployee) {
                    this.listOfEmployees.add(new SalariedEmployee(((SalariedEmployee) EmployeeElements)));
                            //.getAnnualSalary(), EmployeeElements));

                } else if (EmployeeElements instanceof HourlyEmployee) {
                    HourlyEmployee h = (HourlyEmployee) EmployeeElements;
                    this.listOfEmployees.add(new HourlyEmployee(h));
                    //.getHourlyRate(), h.getPeriodHours(), EmployeeElements
                }

            }
        } else {
            System.out.println("Instance of was done incorrectly in the Department class");
        }
    }

    public Department(Department employee) {
        // super(employee);

        if (employee != null) {

            departmentID = employee.departmentID;
            departmentName = employee.departmentName;
            departmentManager = new Manager (employee.departmentManager);
            for (Employee EmployeeElements : employee.listOfEmployees) {
            if (EmployeeElements instanceof SalariedEmployee) {
                    this.listOfEmployees.add(new SalariedEmployee(((SalariedEmployee) EmployeeElements)));
                            //.getAnnualSalary(), EmployeeElements));

                } else if (EmployeeElements instanceof HourlyEmployee) {
                    HourlyEmployee h = (HourlyEmployee) EmployeeElements;
                    this.listOfEmployees.add(new HourlyEmployee(h));
        }
            }}
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(int departmentID) {
        this.departmentID = departmentID;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public ArrayList<Employee> getListOfEmployees() {
        ArrayList<Employee> listOfEmployees = new ArrayList<Employee>();
        
        
        for (Employee EmployeeElements : listOfEmployees) {
            listOfEmployees.add(new Employee(EmployeeElements) {
            });
        }
        return listOfEmployees;
    }

    public void setListOfEmployees(ArrayList<Employee> listOfEmployees) {
        if (listOfEmployees != null) {
            for (Employee EmployeeElements : listOfEmployees) {
                this.listOfEmployees.add(new Employee(EmployeeElements) {
                });
            }
        }
    }

    public Manager getDepartmentManager() {
        return new Manager (departmentManager);
    }

    public void setDepartmentManager(Manager departmentManager) {
        this.departmentManager = new Manager (departmentManager);
    }

    @Override
    public String toString() {
        return "DepartmentID: " + departmentID
                + "\nDepartmentName: " + departmentName
                + "\nDepartmentManager: " + departmentManager
                + "\nList Of Employees: " + listOfEmployees;
    }

    
    public boolean equals(Object obj) {
        Department dept;
        
        if (obj instanceof Department) {
            dept = new Department((Department) obj);
            return this.departmentName.equals(dept.getDepartmentName());
                }
            return false;
        }

        

    

    public int compareTo(Department department) {

        return this.departmentName.compareTo(department.getDepartmentName());

    }

    //fix salaried + hourly
    public void addEmployee(Employee employee) {
        /*
        for (Employee EmployeeElements : employee.listOfEmployees) {
            if (EmployeeElements instanceof SalariedEmployee) {
                    this.listOfEmployees.add(new SalariedEmployee(((SalariedEmployee) EmployeeElements)));
                            //.getAnnualSalary(), EmployeeElements));

                } else if (EmployeeElements instanceof HourlyEmployee) {
                    HourlyEmployee h = (HourlyEmployee) EmployeeElements;
                    this.listOfEmployees.add(new HourlyEmployee(h));
        }
            }}*/
        
        
        if (employee instanceof HourlyEmployee){
            employee = new HourlyEmployee((HourlyEmployee) employee);
            listOfEmployees.add(employee);
        } else if (employee instanceof SalariedEmployee){
            employee = new SalariedEmployee((SalariedEmployee) employee);
            listOfEmployees.add(employee);
            
            
        }
        listOfEmployees.add(new Employee(employee) {
        });

    }

}
