package payrollsystemphase1;

    public class HourlyEmployee extends Employee{
        
        private double hourlyRate;
        private double periodHours;
        
        public HourlyEmployee(int employeeID, String firstName, String lastName) {
            super(employeeID, firstName, lastName);
        }
        
    }
