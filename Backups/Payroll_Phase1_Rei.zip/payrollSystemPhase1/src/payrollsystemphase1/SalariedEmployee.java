package payrollsystemphase1;

 public class SalariedEmployee extends Employee{
        
        private double annualSalary;
        
        public SalariedEmployee(int employeeID, String firstName, String lastName) {
            super(employeeID, firstName, lastName);
        }
        
    }