/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payrollsystemphase1;

import java.util.ArrayList;

/**
 *
 * 
 */
public class Company {

    private String companyName;
    ArrayList<Department> listOfdepartments = new ArrayList<Department>();

    public Company(String companyName, ArrayList<Department> listOfdepartments) {
        this.companyName = companyName;
        // this.listOfdepartments = listOfdepartments;

        //ArrayList<Department> listOfdepartmentsCopy = new ArrayList<Department>(listOfdepartments);
        if (listOfdepartments != null) {

            for (Department DepartmentElements : listOfdepartments) {
                this.listOfdepartments.add(new Department(DepartmentElements));
            }

        }
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public ArrayList<Department> getListOfdepartments() {

        ArrayList<Department> listOfDepartments = new ArrayList<Department>();
        for (Department DepartmentElements : listOfdepartments) {
            listOfDepartments.add(new Department(DepartmentElements));
        }
        return listOfDepartments;
    }

    public void setDepartmentList(ArrayList<Department> listOfdepartments) {
        this.listOfdepartments.clear();
        if (listOfdepartments != null) {
            for (Department DepartmentElements : listOfdepartments) {
                this.listOfdepartments.add(new Department(DepartmentElements));
            }
        }
    }

    @Override
    public String toString() {
        String hour = "CompanyName:" + companyName + "\n" + listOfdepartments;

        return hour;
    }

    public void addDepartment(Department department) {

        listOfdepartments.add(new Department(department));
    }

    public void addEmployeeToDepartment(int deptID, Employee empObject) {

        if (empObject instanceof HourlyEmployee) {
            for (Department dept : listOfdepartments) {
                if (dept.getDepartmentID() == deptID) {
                    empObject = new HourlyEmployee((HourlyEmployee) empObject);
                }
                dept.addEmployee(empObject);
            }
        } else if (empObject instanceof SalariedEmployee) {
            empObject = new SalariedEmployee((SalariedEmployee) empObject);
           // dept.addEmployee(empObject);

        }
    }

    
    /*
                    for (Department dept : listOfdepartments){
                        if (dept.getDepartmentID()==deptID)
                            dept.addEmployee(empObject);

                    }
     */


public void setDepartmentManager(int deptID, Manager manObject){
                
                for (Department dept: listOfdepartments){
                    if (dept.getDepartmentID()==deptID)
                        dept.setDepartmentManager(new Manager(manObject));
                    
                    
                }
            }
    
    }
