/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payrollsystemphase1;

import java.util.ArrayList;

/**
 *
 * @author Rei
 */
    public class SalariedEmployee extends Employee{
        
        private double annualSalary;

        public SalariedEmployee(int employeeID, String firstName, String lastName, ArrayList<Paycheck> listOfPaychecks, double annualSalary) {
            super(employeeID, firstName, lastName, listOfPaychecks);
            this.annualSalary = annualSalary;
        }

        public SalariedEmployee(double annualSalary, Employee employee) {
            super(employee);
            this.annualSalary = annualSalary;
        }
        
        public SalariedEmployee(SalariedEmployee employee) {
            super(employee);
            
            if(employee != null)
            {
            
            annualSalary = employee.annualSalary;
            
                
            }
            
        }
        

        public double getAnnualSalary() {
            return annualSalary;
        }

        public void setAnnualSalary(double annualSalary) {
            this.annualSalary = annualSalary;
        }

        
        @Override
        public String toString() {
            return "SalariedEmployee{" + "annualSalary=" + annualSalary + '}';
        }
        
        
        
        
        
    }

